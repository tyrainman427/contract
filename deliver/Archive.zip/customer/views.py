import json
from django.shortcuts import render, redirect,get_object_or_404
from django.views import View
from django.db.models import Q
from .models import *
from django.core.mail import send_mail
from django.contrib import messages
from django.conf import settings
from django.urls import reverse, reverse_lazy
from datetime import datetime
from django.http import Http404, HttpResponseRedirect
import stripe
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import JsonResponse
from django.contrib.auth import login, authenticate
from .forms import CustomUserCreationForm, CustomAuthenticationForm
from django import forms
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import user_passes_test, login_required
from django.contrib.auth import get_user_model
from django.views.generic import DetailView, UpdateView
from django.db import transaction
from django.urls import reverse
import logging

# Initialize logger
logger = logging.getLogger(__name__)


# Initialize Stripe
stripe.api_key = settings.STRIPE_SECRET_KEY

User = get_user_model()


class OrderForm(forms.ModelForm):
    class Meta:
        model = OrderModel
        fields = [
            'client_full_name', 'contact_person', 'telephone_number', 
            'cell_number', 'date_of_event', 'event_type', 'number_of_guests', 
            'start_time', 'end_time', 'location_of_event', 'telephone_number',
            'email','street_address', 'city', 'state', 'zip_code'
        ]


def register(request):
    if request.user.is_authenticated:
        return redirect('user_dashboard')
    
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('user_dashboard')  # Redirect to a home page or some other page
    else:
        form = CustomUserCreationForm()
    return render(request, 'registration/register.html', {'form': form})

def user_login(request):
    if request.method == 'POST':
        form = CustomAuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('user_dashboard')  # Redirect to a home page or some other page
    else:
        form = CustomAuthenticationForm()
    return render(request, 'login.html', {'form': form})


class Index(View):
    def get(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect('user_dashboard')
        else:
            return render(request, 'customer/index.html')


class About(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'customer/about.html')

class Order(View):
    def get(self, request, *args, **kwargs):
        # Retrieve menu items from each category
        visuals = MenuItem.objects.filter(category__name__contains='Visuals')
        time = MenuItem.objects.filter(category__name__contains='Time')
        photo = MenuItem.objects.filter(category__name__contains='Photo')
        lights = MenuItem.objects.filter(category__name__contains='Lights')
        type_of_payments = OrderModel.objects.all()
        menu_items = MenuItem.objects.all()
        
        cart_items = CartItem.objects.filter(user=request.user)
        order, created = OrderModel.objects.get_or_create(user=request.user, is_paid=False)
        
        # Associate items with the order
        order.items.set([item.menu_item for item in cart_items])

        form = OrderForm(initial={
            'client_full_name': request.user.first_name + ' ' + request.user.last_name,
            'email': request.user.email,
        })
        
        context = {
            'visuals': visuals,
            'time': time,
            'photo': photo,
            'lights': lights,
            'type_of_payments': type_of_payments,
            'form':form,
            'menu_items': menu_items,
        }
        
        return render(request, 'customer/order.html', context)

    def post(self, request, *args, **kwargs):
        try:
            form = OrderForm(request.POST)
            if form.is_valid():
                # This will create a new OrderModel instance and populate it
                # with the data from the form
                order, created = OrderModel.objects.get_or_create(
                    user=request.user,
                    is_paid=False,
                    defaults=form.cleaned_data  # use form.cleaned_data to populate the fields
                )
                
                # If an existing order is found, update its details
                if not created:
                    for field, value in form.cleaned_data.items():
                        setattr(order, field, value)
                    order.save()
                
                items = request.POST.getlist('items[]')
                
                for item_id in items:
                    menu_item = MenuItem.objects.get(pk=item_id)
                    order.items.add(menu_item)  # Assuming 'items' is a ManyToMany field in OrderModel

                return HttpResponseRedirect(reverse('user_dashboard'))
            else:
                print(form.errors)  # Debugging: print errors to the console
                return JsonResponse({"status": "error", "message": "Invalid form data"})
            
        except Exception as e:
            print(f"An error occurred: {e}")  # Debugging: print exceptions to the console
            return JsonResponse({"status": "error", "message": str(e)})

        
        
class OrderConfirmation(LoginRequiredMixin, View):
    def get(self, request, order_id, *args, **kwargs):
        order = OrderModel.objects.get(pk=order_id)
        total_price = order.items.aggregate(total_price=Sum('price'))['total_price']
        # Assuming you have a ForeignKey relationship between OrderModel and OrderItem
        
        is_paid = order.is_paid

        # Send email to customer if the order is paid
        if is_paid:
            email_to_customer_body = "Thank you for your payment! Your order has been confirmed."
            send_mail(
                'Order Confirmation',
                email_to_customer_body,
                settings.DEFAULT_FROM_EMAIL,
                [order.email],
                fail_silently=False
            )

            # Send email to admin
            email_to_admin_body = f"Payment received for order {order.pk}."
            send_mail(
                'Payment Received',
                email_to_admin_body,
                settings.DEFAULT_FROM_EMAIL,
                [settings.ADMIN_EMAIL],  # Replace with the admin's email address
                fail_silently=False
            )

        context = {
            'order': order,
            'is_paid': is_paid,
        }

        return render(request, 'customer/order_confirmation.html', context)

class OrderPayConfirmation(View):
    def get(self, request, *args, **kwargs):
        try:
            # Retrieve the order using any relevant identifier (e.g., order ID)
            order_id = kwargs['order_id']
            order = OrderModel.objects.get(id=order_id)

            # Calculate total_price
            total_price = sum(item.price for item in order.items.all())

            # Mark the order as paid
            order.is_paid = True
            order.payment_account = "right2ya@business.example.com"
            order.save()

            # Render the order confirmation template with the updated order
            context = {
                'order': order,
                'is_paid': True,
                'total_price': total_price  # Include the total price in the context
            }
            return render(request, 'customer/order_confirmation.html', context)

        except OrderModel.DoesNotExist:
            # Handle order not found
            messages.error(request, 'Order not found.')

        # Redirect to the order confirmation page with the original order
        # Render the order confirmation template with the updated order
        context = {
            'order': order,
            'is_paid': True,  # or False depending on your logic
            'total_price': total_price  # Include the total price in the context
        }
        return render(request, 'customer/order_confirmation.html', context)

class Contact(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'customer/contact.html')

class Menu(View):
    def get(self, request, *args, **kwargs):
        menu_items = MenuItem.objects.all()

        context = {
            'menu_items': menu_items,
        }

        return render(request, 'customer/menu.html', context)

class MenuSearch(View):
    def post(self, request, *args, **kwargs):
        search_query = request.POST.get('search_query')

        menu_items = MenuItem.objects.filter(
            Q(name__icontains=search_query) | Q(description__icontains=search_query)
        )

        context = {
            'menu_items': menu_items,
            'search_query': search_query
        }

        return render(request, 'customer/menu_search.html', context)

from django.db import transaction

class AddToCart(View):
    def post(self, request, *args, **kwargs):
        print(f"Entire POST payload: {request.POST}")

        try:
            print("Inside AddToCart post method.")
            
            item_id = request.POST.get('item_id')

            print(f"Item ID received: {item_id}")
            
            menu_item = get_object_or_404(MenuItem, id=item_id)
            print(f"Menu item retrieved: {menu_item}")
            
            user = request.user
            print(f"Current user: {user}")
            
            if user.is_anonymous:
                print("User is anonymous. Exiting.")
                return JsonResponse({"status": "User must be logged in"})
            
            with transaction.atomic():  # Ensuring atomicity for the following operations
                print("Inside atomic block.")
                
                order, created = OrderModel.objects.get_or_create(user=user, is_completed=False)
                print(f"Order retrieved or created: {order}, Created: {created}")
                
                cart_item, created = CartItem.objects.get_or_create(
                    user=user, menu_item=menu_item, order=order, defaults={'quantity': 1})
                print(f"Cart item retrieved or created: {cart_item}, Created: {created}")
                
                if not created:
                    print("Cart item already exists. Updating quantity.")
                    cart_item.quantity += 1
                    cart_item.save()
                
                total_price = sum(item.menu_item.price * item.quantity for item in order.cartitem_set.all())
                print(f"Total price calculated: {total_price}")
                
                order.price = total_price
                order.save()
                print("Order price updated.")
                
            # Inside AddToCart class-based view
            is_cart_empty = (order.cartitem_set.count() == 0)
            total_price = sum(item.menu_item.price * item.quantity for item in order.cartitem_set.all())
            return redirect('order')


            return JsonResponse({"status": "success", "is_cart_empty": is_cart_empty})
        
        except Exception as e:
            print(f"An exception occurred: {e}")
            return JsonResponse({"status": f"An error occurred: {str(e)}"})


class RemoveFromCartView(LoginRequiredMixin, View):
    def post(self, request, *args, **kwargs):
        cart_item_id = request.POST.get('cart_item_id')
        CartItem.objects.get(id=cart_item_id).delete()
        return redirect('cart')

class CheckoutView(LoginRequiredMixin, View):
    def get(self, request, *args, **kwargs):
        cart_items = CartItem.objects.filter(user=request.user)
        total_price = sum(item.menu_item.price * item.quantity for item in cart_items)
        stripe_publishable_key = settings.STRIPE_PUBLISHABLE_KEY
        
        context = {
            'cart_items': cart_items,
            'total_price': total_price,
            'stripe_publishable_key':stripe_publishable_key,
        }
        
        return render(request, 'customer/checkout.html', context)

    def post(self, request, *args, **kwargs):
        token = request.POST.get('stripeToken')
        cart_items = CartItem.objects.filter(user=request.user)
        order = OrderModel.objects.get(user=request.user, is_paid=False)
        
        # Update order with form details
        
        order.client_full_name = request.POST.get('client_full_name')
        order.contact_person = request.POST.get('contact_person')
        order.street_address = request.POST.get('street_address')
        order.telephone_number = request.POST.get('telephone_number')
        order.cell_number = request.POST.get('cell_number')
        order.date_of_event = request.POST.get('date_of_event')
        order.event_type = request.POST.get('event_type')
        order.number_of_guests = request.POST.get('number_of_guests')
        order.start_time = request.POST.get('start_time')
        order.end_time = request.POST.get('end_time')
        order.location_of_event = request.POST.get('location_of_event')
        order.email = request.POST.get('email')
        order.city = request.POST.get('city')
        order.state = request.POST.get('state')
        order.zip_code = request.POST.get('zip_code')
        
        
        total_price = sum(item.menu_item.price * item.quantity for item in cart_items)
        
        
        with transaction.atomic():  # Ensures database consistency
            total_price = sum(item.menu_item.price * item.quantity for item in cart_items)
            total_price_cents = int(total_price * 100)
            
            customer_email = request.user.email  # Assuming the email is stored in user model
            customer_name = request.user.username 

            # Create a Stripe charge
            try:
                charge = stripe.Charge.create(
                    amount=total_price_cents,
                    currency="usd",
                    source=token,
                    description=f"Charge for {request.user.email}",
                    metadata={
                        "customer_email": customer_email,
                        "customer_name": customer_name,
                    }
                    
                )

                # Update the order to mark it as paid
                order.is_paid = True
                order.save()

                # Clear the cart
                CartItem.objects.filter(user=request.user).delete()

                return redirect(reverse('payment_confirmation', args=[order.id]))

            except stripe.error.CardError as e:
                messages.error(request, "Your card has been declined.")
        

class Cart(View):
    def get(self, request, *args, **kwargs):
        cart_items = CartItem.objects.filter(user=request.user)
        total_price = sum(item.menu_item.price * item.quantity for item in cart_items)

        context = {'cart_items': cart_items,
                   'total_price': total_price}
        return render(request, 'customer/cart.html', context)

@login_required
def user_dashboard_view(request):
    current_user = request.user
    user_orders = OrderModel.objects.filter(user=current_user.id)  # Filter by user id
    context = {
        'user_orders': user_orders,
    }
    return render(request, 'customer/user_dashboard.html', context)


@user_passes_test(lambda u: u.is_superuser)
def admin_dashboard_view(request):
    # your logic here
    return render(request, 'customer/admin_dashboard.html')

@method_decorator(login_required, name='dispatch')
class OrderDetailView(DetailView):
    model = OrderModel
    template_name = 'customer/order_detail.html'
    context_object_name = 'order'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['is_paid'] = self.object.is_paid
        context['menu_items'] = MenuItem.objects.all()

        # Calculate cart total
        user = self.request.user
        order = OrderModel.objects.get(user=user, is_completed=False)

        total_price = sum(item.menu_item.price * item.quantity for item in order.cartitem_set.all())
        cart_items = CartItem.objects.filter(user=user)

        context['total_cost'] = total_price
        context['cart_items'] = cart_items
        print("Cart: ",cart_items)

  
        logger.debug(f"Cart Items: {self.object.items.all()}")

        return context


    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        menuItem_id = request.POST.get('menuItem_id')
        
        logger.debug(f"Received POST with menuItem_id: {menuItem_id}")

        try:
            menu_item = MenuItem.objects.get(id=menuItem_id)
            self.object.items.add(menu_item)
            self.object.save()
            logger.debug("Item successfully added and order saved.")
            status = 'success'
        except MenuItem.DoesNotExist:
            logger.warning(f"MenuItem with id {menuItem_id} does not exist.")
            status = 'error'
        except Exception as e:
            logger.error(f"An unexpected error occurred: {e}")
            status = 'error'

        if request.is_ajax():
            return JsonResponse({'status': status})

        return redirect('order-detail', pk=self.object.pk)

def update_quantity(request):
    if request.method == 'POST':
        cart_item_id = request.POST.get('cart_item_id')
        quantity = int(request.POST.get('quantity'))

        # Find the cart item and update its quantity
        cart_item = CartItem.objects.get(id=cart_item_id)
        cart_item.quantity = quantity
        cart_item.save()
        
    messages.add_message(request, messages.SUCCESS, 'Quantity updated.')

    return redirect('cart')  # Redirect back to the cart page

@method_decorator(login_required, name='dispatch')
class OrderUpdateView(UpdateView):
    model = OrderModel
    fields = [
            'client_full_name', 'contact_person', 'street_address', 'telephone_number', 
            'cell_number', 'date_of_event', 'event_type', 'number_of_guests', 
            'start_time', 'end_time', 'location_of_event', 
            'email', 'city', 'state', 'zip_code'
        ]  # Fields that you want to be editable
    template_name = 'customer/order_edit.html'
    success_url = reverse_lazy('user_dashboard')

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)
    

@login_required
def order_pay_view(request, pk):
    # Implement your logic for payment here
    # You could, for example, redirect to a payment gateway page
    return redirect(reverse('payment_confirmation', args=[pk]))

@login_required
def order_add_services_view(request, pk):
    # Implement logic to add services to the order
    # You could use AJAX here to send data without page reload
    if request.method == 'POST':
        # Extract data from POST request and add services
        # Return a JsonResponse if you're using AJAX
        return JsonResponse({'status': 'success'})

    return render(request, 'customer/add_services.html', {'order_id': pk})
